from pyspark.sql import SparkSession

spark=SparkSession.builder.appName("MySparkApp").getOrCreate()

df=spark.read.csv("input_data.csv",header=True,inferSchema=True)

df.write.csv("output_data.csv",header=True)

spark.stop()
